import tkinter as tk

# Library Item class
class LibraryItem:
    def __init__(self, item_name, author, publisher):
        self.item_name = item_name
        self.author = author
        self.publisher = publisher

# Book class extending Library Item
class Book(LibraryItem):
    def __init__(self, item_name, author, publisher, title, num_pages, has_ebook):
        super().__init__(item_name, author, publisher)
        self.title = title
        self.num_pages = num_pages
        self.has_ebook = has_ebook

# Function to create a Book object and display information
def create_book():
    item_name = item_name_entry.get()
    author = author_entry.get()
    publisher = publisher_entry.get()
    title = title_entry.get()
    num_pages = int(num_pages_entry.get())
    has_ebook = ebook_var.get() == 1

    book = Book(item_name, author, publisher, title, num_pages, has_ebook)

    result_label.config(text="Book Information:")
    result_text.config(text=f"Title: {book.title}\nAuthor: {book.author}\nPublisher: {book.publisher}\nNumber of Pages: {book.num_pages}\nEbook Version Available: {'Yes' if book.has_ebook else 'No'}")

# Create the main application window
app = tk.Tk()
app.title("Library Information System")

# Labels and Entry widgets for user input
item_name_label = tk.Label(app, text="Item Name:")
item_name_label.grid(row=0, column=0)
item_name_entry = tk.Entry(app)
item_name_entry.grid(row=0, column=1)

author_label = tk.Label(app, text="Author:")
author_label.grid(row=1, column=0)
author_entry = tk.Entry(app)
author_entry.grid(row=1, column=1)

publisher_label = tk.Label(app, text="Publisher:")
publisher_label.grid(row=2, column=0)
publisher_entry = tk.Entry(app)
publisher_entry.grid(row=2, column=1)

title_label = tk.Label(app, text="Book Title:")
title_label.grid(row=3, column=0)
title_entry = tk.Entry(app)
title_entry.grid(row=3, column=1)

num_pages_label = tk.Label(app, text="Number of Pages:")
num_pages_label.grid(row=4, column=0)
num_pages_entry = tk.Entry(app)
num_pages_entry.grid(row=4, column=1)

ebook_label = tk.Label(app, text="Ebook Version Available:")
ebook_label.grid(row=5, column=0)
ebook_var = tk.IntVar()
ebook_checkbox = tk.Checkbutton(app, variable=ebook_var)
ebook_checkbox.grid(row=5, column=1)

# Button to create a Book object and display information
create_button = tk.Button(app, text="Create Book", command=create_book)
create_button.grid(row=6, column=0, columnspan=2)

# Label to display Book information
result_label = tk.Label(app, text="")
result_label.grid(row=7, column=0, columnspan=2)
result_text = tk.Label(app, text="")
result_text.grid(row=8, column=0, columnspan=2)

# Start the application
app.mainloop()
