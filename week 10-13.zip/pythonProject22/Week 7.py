import tkinter as tk

# Function to write words to a file
def write_words_to_file_gui():
    num_words = int(entry.get())
    with open("word_list.txt", "w") as file:
        for _ in range(num_words):
            word = input_word.get()
            file.write(word + "\n")
            input_word.delete(0, tk.END)

# Function to read and display data
def read_words_from_file_gui():
    with open("word_list.txt", "r") as file:
        words = file.read().splitlines()

    num_words = len(words)
    longest_word = max(words, key=len)
    average_length = sum(len(word) for word in words) / num_words if num_words > 0 else 0

    result_label.config(text=f"Number of words in the file: {num_words}\nLongest word in the file: {longest_word}\nAverage length of words: {average_length:.2f}")

# Create a GUI window
root = tk.Tk()
root.title("Word List File Writer and Reader")

# Label and Entry for number of words
label = tk.Label(root, text="How many words would you like to write to a file?")
label.pack()
entry = tk.Entry(root)
entry.pack()

# Entry for word input
input_word = tk.Entry(root)
input_word.pack()

# Buttons to write and read
write_button = tk.Button(root, text="Write to File", command=write_words_to_file_gui)
write_button.pack()
read_button = tk.Button(root, text="Read and Display", command=read_words_from_file_gui)
read_button.pack()

# Label to display results
result_label = tk.Label(root, text="")
result_label.pack()

root.mainloop()



