# Library Item class
class LibraryItem:
    def __init__(self, item_name, author, publisher):
        self.item_name = item_name
        self.author = author
        self.publisher = publisher

    def get_item_name(self):
        return self.item_name

    def set_item_name(self, item_name):
        self.item_name = item_name

    def get_author(self):
        return self.author

    def set_author(self, author):
        self.author = author

    def get_publisher(self):
        return self.publisher

    def set_publisher(self, publisher):
        self.publisher = publisher

# Book class extending Library Item
class Book(LibraryItem):
    def __init__(self, item_name, author, publisher, title, num_pages, has_ebook):
        super().__init__(item_name, author, publisher)
        self.title = title
        self.num_pages = num_pages
        self.has_ebook = has_ebook

    def get_title(self):
        return self.title

    def set_title(self, title):
        self.title = title

    def get_num_pages(self):
        return self.num_pages

    def set_num_pages(self, num_pages):
        self.num_pages = num_pages

    def has_ebook_version(self):
        return self.has_ebook

    def set_ebook_version(self, has_ebook):
        self.has_ebook = has_ebook

# Interactive input
print("Welcome to the Library Information System!")

item_name = input("Enter the item name: ")
author = input("Enter the author: ")
publisher = input("Enter the publisher: ")

title = input("Enter the book title: ")
num_pages = int(input("Enter the number of pages: "))
has_ebook = input("Is there an eBook version? (yes/no): ").lower() == "yes"

# Create instances of LibraryItem and Book
item1 = LibraryItem(item_name, author, publisher)
book = Book(item_name, author, publisher, title, num_pages, has_ebook)

# Display information
print("\nLibrary Item Information:")
print(f"Item Name: {item1.get_item_name()}")
print(f"Author: {item1.get_author()}")
print(f"Publisher: {item1.get_publisher()}")

print("\nBook Information:")
print(f"Title: {book.get_title()}")
print(f"Author: {book.get_author()}")
print(f"Publisher: {book.get_publisher()}")
print(f"Number of Pages: {book.get_num_pages()}")
print(f"Ebook Version Available: {book.has_ebook_version()}")



