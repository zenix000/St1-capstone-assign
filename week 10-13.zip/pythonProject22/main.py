# (a) Word List File Writer
def write_words_to_file():
    num_words = int(input("How many words would you like to write to a file? "))

    with open("word_list.txt", "w") as file:
        for _ in range(num_words):
            word = input("Enter a word: ")
            file.write(word + "\n")


# (b) Word List File Reader
def read_words_from_file():
    with open("word_list.txt", "r") as file:
        words = file.read().splitlines()

    num_words = len(words)
    longest_word = max(words, key=len)
    average_length = sum(len(word) for word in words) / num_words if num_words > 0 else 0

    print(f"Number of words in the file: {num_words}")
    print(f"Longest word in the file: {longest_word}")
    print(f"Average length of words: {average_length:.2f}")


if __name__ == "__main__":
    write_words_to_file()
    read_words_from_file()




