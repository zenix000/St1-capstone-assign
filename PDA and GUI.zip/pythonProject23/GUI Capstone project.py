import tkinter as tk
from keras.models import load_model
from PIL import Image, ImageOps, ImageTk  # Import ImageTk
import numpy as np

# Disable scientific notation for clarity
np.set_printoptions(suppress=True)
model = load_model("keras_Model.h5", compile=False)
class_names = open("labels.txt", "r").readlines()

def make_prediction():
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

    # Load the image from the project directory
    image = Image.open("IMG-20180327-WA0043.jpg").convert("RGB")
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)
    image_array = np.asarray(image)
    normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1
    data[0] = normalized_image_array
    prediction = model.predict(data)
    index = np.argmax(prediction)
    class_name = class_names[index]
    confidence_score = prediction[0][index]

    # Display prediction and confidence score in the GUI
    result_label.config(text=f"Class: {class_name[2:]}")
    score_label.config(text=f"Confidence Score: {confidence_score:.4f}")

    # Display the image in the GUI using ImageTk
    image.thumbnail((400, 400))
    photo = ImageTk.PhotoImage(image)
    image_label.config(image=photo)
    image_label.image = photo

# Create the main application window
app = tk.Tk()
app.title("Diabetic Retinopathy Severity Classifier")

# window size to 400x400
app.geometry("400x400")

# Button to classify the image
classify_button = tk.Button(app, text="Classify Image", command=make_prediction)
classify_button.pack(pady=10)

# Labels
result_label = tk.Label(app, text="", font=("terminal", 16))
result_label.pack()
score_label = tk.Label(app, text="", font=("terminal", 16))
score_label.pack()

image_label = tk.Label(app)
image_label.pack()

# Start the application
app.mainloop()

